import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
export default class UserProfile extends Component {




    render() {
        return (

                <div>
                    <div class="card" Style="width:17rem;" >
                        <img src="https://iisy.fi/wp-content/uploads/2018/08/user-profile-male-logo.jpg" class="card-img-top" alt="..." />
                        <a href="ww" class="card-link">Edit</a>
                        <h5 class="card-title" Style="text-align:center;">User 1</h5>


                        <ul class="list-group list-group-flush">
                            <li class="list-group-item list-group-item-action"><a href="ww" class="nav-link">My Orders<i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
                            <li class="list-group-item list-group-item-action"><a href="ww" class="nav-link">WishList<i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
                            <li class="list-group-item list-group-item-action"><a href="ww" class="nav-link">Manage seller account<i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
                            <li class="list-group-item list-group-item-action"><a href="ww" class="nav-link">Help and Support<i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
                        </ul>

                    </div>
                </div>
    


        );

    }

}