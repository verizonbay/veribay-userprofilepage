import React from 'react';
import './App.css';
import UserProfile from './userprofile'
function App() {
  return (<div>
<UserProfile/>
    </div>
  );
}

export default App;
